using System;
using System.Collections.Generic;
using System.Linq;

// ═══════════════════════════════════════════════════════════════════════════════
//  CATALOGUE DES MODULES SOUS LICENCE — fichier PARTAGÉ (application + générateur)
//
//  Pour ajouter un module : créer son code ici, l'associer à son ViewModel dans
//  ModuleParEcran, puis recompiler l'application ET le générateur. Un code déjà
//  émis dans des licences ne doit jamais être renommé.
// ═══════════════════════════════════════════════════════════════════════════════

namespace IUTSCalculator.Licensing
{
    public sealed class ModuleLicence
    {
        public ModuleLicence(string code, string libelle, bool obligatoire)
        {
            Code = code;
            Libelle = libelle;
            Obligatoire = obligatoire;
        }

        public string Code { get; }
        public string Libelle { get; }

        /// <summary>Module socle, toujours inclus dans une licence.</summary>
        public bool Obligatoire { get; }
    }

    public static class LicenceModules
    {
        public const string Paie = "PAIE";
        public const string Declarations = "DECL";
        public const string EtatsComptables = "COMPTA";
        public const string Organigramme = "RH01";
        public const string SuiviPostes = "RH02";
        public const string Entretiens = "RH03";
        public const string Formation = "RH04";
        public const string Recrutement = "RH05";
        public const string Discipline = "RH06";
        public const string SanteSecurite = "RH07";
        public const string GestionTemps = "RH08";

        public static readonly IReadOnlyList<ModuleLicence> Catalogue = new List<ModuleLicence>
        {
            new ModuleLicence(Paie, "Paie & salariés (socle : calcul, bulletins, variables, absences, prêts…)", true),
            new ModuleLicence(Declarations, "Déclarations CNSS, IUTS/TPA et état annuel des salaires", false),
            new ModuleLicence(EtatsComptables, "Livre de paie, écritures comptables, ordres de virement, tableau de bord", false),
            new ModuleLicence(Organigramme, "RH-01 Organigramme", false),
            new ModuleLicence(SuiviPostes, "RH-02 Suivi des postes & budget", false),
            new ModuleLicence(Entretiens, "RH-03 Entretiens & évaluations", false),
            new ModuleLicence(Formation, "RH-04 Formation & TPA", false),
            new ModuleLicence(Recrutement, "RH-05 Recrutement & candidatures", false),
            new ModuleLicence(Discipline, "RH-06 Discipline & procédures", false),
            new ModuleLicence(SanteSecurite, "RH-07 Santé & sécurité au travail", false),
            new ModuleLicence(GestionTemps, "RH-08 Gestion des temps & rotations", false)
        };

        /// <summary>
        /// Écran (nom du type de ViewModel) → module requis. Un écran absent de cette table
        /// relève du socle PAIE : il exige donc quand même une licence valide.
        /// </summary>
        private static readonly Dictionary<string, string> ModuleParEcran = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            { "DeclarationCnssViewModel", Declarations },
            { "DeclarationIutsTpaViewModel", Declarations },
            { "EtatAnnuelSalairesViewModel", Declarations },

            { "LivrePaieViewModel", EtatsComptables },
            { "EcriturePaieViewModel", EtatsComptables },
            { "OrdreVirementViewModel", EtatsComptables },
            { "TableauBordMasseSalarialeViewModel", EtatsComptables },

            { "OrganigrammeViewModel", Organigramme },
            { "SuiviPostesBudgetViewModel", SuiviPostes },
            { "EntretiensEvaluationsViewModel", Entretiens },
            { "FormationViewModel", Formation },
            { "RecrutementViewModel", Recrutement },
            { "DisciplineViewModel", Discipline },
            { "SanteSecuriteViewModel", SanteSecurite },
            { "GestionTempsViewModel", GestionTemps }
        };

        public static string ModulePourEcran(string nomTypeViewModel)
        {
            string code;
            if (nomTypeViewModel != null && ModuleParEcran.TryGetValue(nomTypeViewModel, out code))
                return code;
            return Paie;
        }

        public static string Libelle(string code)
        {
            var m = Catalogue.FirstOrDefault(x => x.Code == code);
            return m != null ? m.Libelle : code;
        }

        public static bool EstConnu(string code)
        {
            return Catalogue.Any(x => x.Code == code);
        }
    }
}
