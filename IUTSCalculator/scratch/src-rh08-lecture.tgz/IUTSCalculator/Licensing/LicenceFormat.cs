using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Signers;
using Org.BouncyCastle.Security;

// ═══════════════════════════════════════════════════════════════════════════════
//  FORMAT DES LICENCES SIGMA PAIE & RH — fichier PARTAGÉ
//
//  Ce fichier est compilé à l'identique dans l'application ET dans le générateur
//  de licences (lien de fichier dans Outils\SigmaLicenceGenerateur). Toute
//  modification du format doit donc se faire ICI et nulle part ailleurs : une
//  divergence entre les deux côtés rendrait toutes les licences invalides.
//
//  Principe de sécurité : chaque licence est signée en Ed25519. La clé PRIVÉE ne
//  quitte jamais le poste de l'éditeur (fichier chiffré du générateur) ; l'appli-
//  cation ne contient que la clé PUBLIQUE, qui permet de vérifier mais pas de
//  signer. Connaître ce code source, ou décompiler l'application, ne permet donc
//  pas de fabriquer une licence valide.
//
//  Contrainte : C# 7.3 (projet .NET Framework 4.8 « ancien format »).
// ═══════════════════════════════════════════════════════════════════════════════

namespace IUTSCalculator.Licensing
{
    /// <summary>Nature de la licence.</summary>
    public enum TypeLicence
    {
        Essai = 1,
        Annuelle = 2,
        Perpetuelle = 3
    }

    /// <summary>
    /// Contenu signé d'une licence. Sérialisé dans un ordre de champs FIXE, en texte
    /// UTF-8 : la signature porte sur ces octets exacts, et l'analyse refuse toute
    /// forme qui ne se re-sérialise pas à l'identique (pas d'ambiguïté exploitable).
    /// </summary>
    public sealed class LicenceContenu
    {
        public const int FormatActuel = 1;
        public const string ProduitAttendu = "SIGMA-PAIE-RH";

        private static readonly string[] OrdreDesChamps =
        {
            "format", "produit", "id", "type", "titulaire", "ifu", "emission",
            "expiration", "finmaj", "modules", "dossiers", "empreinte", "reinithorloge"
        };

        private static readonly Regex RegexId = new Regex("^[0-9a-f]{32}$", RegexOptions.CultureInvariant);
        private static readonly Regex RegexModule = new Regex("^[A-Z0-9]{2,12}$", RegexOptions.CultureInvariant);

        /// <summary>Identifiant unique (GUID, 32 caractères hexadécimaux minuscules).</summary>
        public string Id { get; set; }

        public TypeLicence Type { get; set; }

        /// <summary>Raison sociale du client titulaire (imprimée sur les documents).</summary>
        public string Titulaire { get; set; }

        /// <summary>IFU du client titulaire.</summary>
        public string Ifu { get; set; }

        /// <summary>Date et heure d'émission (UTC, à la seconde).</summary>
        public DateTime EmissionUtc { get; set; }

        /// <summary>Dernier jour d'utilisation (inclus). Obligatoire pour Essai et Annuelle, absent pour Perpétuelle.</summary>
        public DateTime? Expiration { get; set; }

        /// <summary>Licence perpétuelle : versions publiées jusqu'à cette date couvertes. Facultatif.</summary>
        public DateTime? FinMisesAJour { get; set; }

        /// <summary>Codes des modules autorisés (voir <c>LicenceModules</c>).</summary>
        public IList<string> Modules { get; set; } = new List<string>();

        /// <summary>
        /// Facultatif : si renseigné, seuls les dossiers dont l'IFU figure dans cette liste
        /// peuvent être ouverts (licence mono-entreprise). Vide = tous les dossiers.
        /// </summary>
        public IList<string> DossiersIfu { get; set; } = new List<string>();

        /// <summary>Empreinte matérielle du poste autorisé (voir <c>CodeDemande</c>).</summary>
        public byte[] Empreinte { get; set; }

        /// <summary>
        /// Si vrai, l'activation de cette licence réinitialise la mémoire d'horloge du poste
        /// (déblocage signé après une date système erronée).
        /// </summary>
        public bool ReinitHorloge { get; set; }

        // ───────────────────────────────────────────────────────────── Sérialisation

        public byte[] Serialiser()
        {
            Valider();

            var sb = new StringBuilder();
            Ligne(sb, "format", FormatActuel.ToString(CultureInfo.InvariantCulture));
            Ligne(sb, "produit", ProduitAttendu);
            Ligne(sb, "id", Id);
            Ligne(sb, "type", Type.ToString());
            Ligne(sb, "titulaire", Nettoyer(Titulaire));
            Ligne(sb, "ifu", Nettoyer(Ifu));
            Ligne(sb, "emission", EmissionUtc.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture));
            Ligne(sb, "expiration", FormatDate(Expiration));
            Ligne(sb, "finmaj", FormatDate(FinMisesAJour));
            Ligne(sb, "modules", string.Join(",", Modules));
            Ligne(sb, "dossiers", string.Join(",", DossiersIfu.Select(Nettoyer)));
            Ligne(sb, "empreinte", Convert.ToBase64String(Empreinte));
            Ligne(sb, "reinithorloge", ReinitHorloge ? "1" : "0");
            return new UTF8Encoding(false).GetBytes(sb.ToString());
        }

        /// <summary>
        /// Analyse STRICTE : ordre des champs imposé, aucun champ inconnu ou manquant, et le
        /// résultat doit se re-sérialiser octet pour octet à l'identique.
        /// </summary>
        public static LicenceContenu Analyser(byte[] octets)
        {
            if (octets == null || octets.Length == 0 || octets.Length > 8192)
                throw new FormatException("Contenu de licence vide ou trop volumineux.");

            string texte;
            try
            {
                texte = new UTF8Encoding(false, true).GetString(octets);
            }
            catch (DecoderFallbackException)
            {
                throw new FormatException("Contenu de licence illisible.");
            }

            if (!texte.EndsWith("\n", StringComparison.Ordinal))
                throw new FormatException("Contenu de licence tronqué.");

            var lignes = texte.Substring(0, texte.Length - 1).Split('\n');
            if (lignes.Length != OrdreDesChamps.Length)
                throw new FormatException("Nombre de champs de licence incorrect.");

            var valeurs = new Dictionary<string, string>(StringComparer.Ordinal);
            for (int i = 0; i < lignes.Length; i++)
            {
                int pos = lignes[i].IndexOf('=');
                if (pos <= 0)
                    throw new FormatException("Ligne de licence mal formée.");
                string cle = lignes[i].Substring(0, pos);
                if (cle != OrdreDesChamps[i])
                    throw new FormatException("Champ de licence inattendu : " + cle);
                valeurs[cle] = lignes[i].Substring(pos + 1);
            }

            if (valeurs["format"] != FormatActuel.ToString(CultureInfo.InvariantCulture))
                throw new FormatException("Version de format de licence non prise en charge.");
            if (valeurs["produit"] != ProduitAttendu)
                throw new FormatException("Cette licence ne concerne pas Sigma Paie & RH.");

            TypeLicence type;
            if (!Enum.TryParse(valeurs["type"], false, out type) || !Enum.IsDefined(typeof(TypeLicence), type)
                || type.ToString() != valeurs["type"])
                throw new FormatException("Type de licence inconnu.");

            DateTime emission;
            if (!DateTime.TryParseExact(valeurs["emission"], "yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture,
                    DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out emission))
                throw new FormatException("Date d'émission invalide.");

            byte[] empreinte;
            try { empreinte = Convert.FromBase64String(valeurs["empreinte"]); }
            catch (FormatException) { throw new FormatException("Empreinte de licence invalide."); }

            if (valeurs["reinithorloge"] != "0" && valeurs["reinithorloge"] != "1")
                throw new FormatException("Champ reinithorloge invalide.");

            var contenu = new LicenceContenu
            {
                Id = valeurs["id"],
                Type = type,
                Titulaire = valeurs["titulaire"],
                Ifu = valeurs["ifu"],
                EmissionUtc = DateTime.SpecifyKind(emission, DateTimeKind.Utc),
                Expiration = AnalyserDate(valeurs["expiration"]),
                FinMisesAJour = AnalyserDate(valeurs["finmaj"]),
                Modules = Decouper(valeurs["modules"]),
                DossiersIfu = Decouper(valeurs["dossiers"]),
                Empreinte = empreinte,
                ReinitHorloge = valeurs["reinithorloge"] == "1"
            };

            // Garde-fou final : la forme canonique doit être exactement celle reçue.
            byte[] recalcule = contenu.Serialiser();
            if (!OctetsEgaux(recalcule, octets))
                throw new FormatException("Contenu de licence non canonique.");

            return contenu;
        }

        private void Valider()
        {
            if (Id == null || !RegexId.IsMatch(Id))
                throw new InvalidOperationException("Identifiant de licence invalide.");
            if (!Enum.IsDefined(typeof(TypeLicence), Type))
                throw new InvalidOperationException("Type de licence invalide.");
            if (string.IsNullOrWhiteSpace(Titulaire))
                throw new InvalidOperationException("Le titulaire de la licence est obligatoire.");
            if (EmissionUtc.Kind != DateTimeKind.Utc)
                throw new InvalidOperationException("La date d'émission doit être en UTC.");
            if (Empreinte == null || Empreinte.Length != CodeDemande.TailleEmpreinte)
                throw new InvalidOperationException("Empreinte matérielle invalide.");
            if (Modules == null || Modules.Count == 0)
                throw new InvalidOperationException("Au moins un module doit être autorisé.");
            foreach (var m in Modules)
                if (m == null || !RegexModule.IsMatch(m))
                    throw new InvalidOperationException("Code module invalide : " + m);
            if (Modules.Distinct(StringComparer.Ordinal).Count() != Modules.Count)
                throw new InvalidOperationException("Module en double.");
            foreach (var d in DossiersIfu)
                if (string.IsNullOrWhiteSpace(d) || d.Contains(","))
                    throw new InvalidOperationException("IFU de dossier invalide.");

            switch (Type)
            {
                case TypeLicence.Essai:
                case TypeLicence.Annuelle:
                    if (!Expiration.HasValue)
                        throw new InvalidOperationException("Une licence d'essai ou annuelle doit avoir une date d'expiration.");
                    if (FinMisesAJour.HasValue)
                        throw new InvalidOperationException("La fin des mises à jour ne concerne que les licences perpétuelles.");
                    break;
                case TypeLicence.Perpetuelle:
                    if (Expiration.HasValue)
                        throw new InvalidOperationException("Une licence perpétuelle n'a pas de date d'expiration.");
                    break;
            }
        }

        private static void Ligne(StringBuilder sb, string cle, string valeur)
        {
            sb.Append(cle).Append('=').Append(valeur ?? string.Empty).Append('\n');
        }

        private static string Nettoyer(string valeur)
        {
            if (valeur == null) return string.Empty;
            var sb = new StringBuilder(valeur.Length);
            foreach (char c in valeur)
                if (!char.IsControl(c)) sb.Append(c);
            return sb.ToString().Trim();
        }

        private static string FormatDate(DateTime? date)
        {
            return date.HasValue ? date.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : string.Empty;
        }

        private static DateTime? AnalyserDate(string texte)
        {
            if (texte.Length == 0) return null;
            DateTime d;
            if (!DateTime.TryParseExact(texte, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d))
                throw new FormatException("Date de licence invalide : " + texte);
            return d.Date;
        }

        private static IList<string> Decouper(string texte)
        {
            if (texte.Length == 0) return new List<string>();
            return texte.Split(',').ToList();
        }

        public static bool OctetsEgaux(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }

    /// <summary>Signature et vérification Ed25519 (BouncyCastle).</summary>
    public static class LicenceCrypto
    {
        /// <summary>Séparation de domaine : une signature de licence n'est valable que comme licence.</summary>
        public const string DomaineLicence = "SIGMA-PAIE-RH|LICENCE|v1\n";

        /// <summary>Séparation de domaine pour les réponses du serveur de vérification en ligne.</summary>
        public const string DomaineServeur = "SIGMA-PAIE-RH|SERVEUR|v1\n";

        public const int TailleCle = 32;
        public const int TailleSignature = 64;

        public static void GenererPaire(out byte[] clePrivee, out byte[] clePublique)
        {
            var aleatoire = new SecureRandom();
            var privee = new Ed25519PrivateKeyParameters(aleatoire);
            clePrivee = privee.GetEncoded();
            clePublique = privee.GeneratePublicKey().GetEncoded();
        }

        public static byte[] ClePubliqueDepuisPrivee(byte[] clePrivee)
        {
            return new Ed25519PrivateKeyParameters(clePrivee, 0).GeneratePublicKey().GetEncoded();
        }

        public static byte[] Signer(byte[] clePrivee, byte[] donnees, string domaine)
        {
            if (clePrivee == null || clePrivee.Length != TailleCle)
                throw new ArgumentException("Clé privée invalide.");
            var signataire = new Ed25519Signer();
            signataire.Init(true, new Ed25519PrivateKeyParameters(clePrivee, 0));
            byte[] message = AvecDomaine(donnees, domaine);
            signataire.BlockUpdate(message, 0, message.Length);
            return signataire.GenerateSignature();
        }

        /// <summary>Ne lève jamais d'exception : toute anomalie vaut « signature invalide ».</summary>
        public static bool Verifier(byte[] clePublique, byte[] donnees, byte[] signature, string domaine)
        {
            try
            {
                if (clePublique == null || clePublique.Length != TailleCle) return false;
                if (signature == null || signature.Length != TailleSignature) return false;
                if (donnees == null) return false;
                if (clePublique.All(b => b == 0)) return false; // clé non configurée

                var verificateur = new Ed25519Signer();
                verificateur.Init(false, new Ed25519PublicKeyParameters(clePublique, 0));
                byte[] message = AvecDomaine(donnees, domaine);
                verificateur.BlockUpdate(message, 0, message.Length);
                return verificateur.VerifySignature(signature);
            }
            catch
            {
                return false;
            }
        }

        private static byte[] AvecDomaine(byte[] donnees, string domaine)
        {
            byte[] d = Encoding.ASCII.GetBytes(domaine);
            var resultat = new byte[d.Length + donnees.Length];
            Buffer.BlockCopy(d, 0, resultat, 0, d.Length);
            Buffer.BlockCopy(donnees, 0, resultat, d.Length, donnees.Length);
            return resultat;
        }
    }

    /// <summary>
    /// Fichier licence (.lic) : contenu et signature en Base64 entre deux balises. Les
    /// lignes commençant par « # » sont purement informatives et ignorées : les modifier
    /// ne change rien, seule la partie signée fait foi.
    /// </summary>
    public static class LicenceFichier
    {
        public const string Debut = "BEGIN-SIGMA-LICENCE";
        public const string Separateur = "SIGNATURE";
        public const string Fin = "END-SIGMA-LICENCE";

        public static string Encoder(LicenceContenu contenu, byte[] contenuOctets, byte[] signature)
        {
            var sb = new StringBuilder();
            sb.AppendLine("# Licence Sigma Paie & RH");
            sb.AppendLine("# Titulaire  : " + contenu.Titulaire);
            sb.AppendLine("# IFU        : " + contenu.Ifu);
            sb.AppendLine("# Type       : " + contenu.Type);
            sb.AppendLine("# Expiration : " + (contenu.Expiration.HasValue
                ? contenu.Expiration.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) : "aucune"));
            sb.AppendLine("# Ce fichier est signé : toute modification le rend inutilisable.");
            sb.AppendLine(Debut);
            foreach (var morceau in Decouper(Convert.ToBase64String(contenuOctets), 64))
                sb.AppendLine(morceau);
            sb.AppendLine(Separateur);
            sb.AppendLine(Convert.ToBase64String(signature));
            sb.AppendLine(Fin);
            return sb.ToString();
        }

        public static bool TryDecoder(string texte, out byte[] contenuOctets, out byte[] signature, out string erreur)
        {
            contenuOctets = null;
            signature = null;
            erreur = null;

            if (string.IsNullOrWhiteSpace(texte) || texte.Length > 64 * 1024)
            {
                erreur = "Le texte de licence est vide ou trop long.";
                return false;
            }

            var lignes = texte.Replace("\r", string.Empty).Split('\n')
                .Select(l => l.Trim())
                .Where(l => l.Length > 0 && !l.StartsWith("#", StringComparison.Ordinal))
                .ToList();

            int iDebut = lignes.IndexOf(Debut);
            int iSep = lignes.IndexOf(Separateur);
            int iFin = lignes.IndexOf(Fin);
            if (iDebut < 0 || iSep <= iDebut + 1 || iFin != iSep + 2)
            {
                erreur = "Le texte fourni n'est pas une licence Sigma Paie & RH complète.";
                return false;
            }

            try
            {
                contenuOctets = Convert.FromBase64String(string.Concat(lignes.Skip(iDebut + 1).Take(iSep - iDebut - 1)));
                signature = Convert.FromBase64String(lignes[iSep + 1]);
            }
            catch (FormatException)
            {
                erreur = "La licence est endommagée (encodage invalide).";
                contenuOctets = null;
                signature = null;
                return false;
            }

            if (signature.Length != LicenceCrypto.TailleSignature)
            {
                erreur = "La signature de la licence est endommagée.";
                return false;
            }
            return true;
        }

        private static IEnumerable<string> Decouper(string s, int taille)
        {
            for (int i = 0; i < s.Length; i += taille)
                yield return s.Substring(i, Math.Min(taille, s.Length - i));
        }
    }

    /// <summary>
    /// Code de demande d'activation : l'empreinte matérielle du poste (5 composants de
    /// 5 octets), une version et une somme de contrôle, encodés en Base32 Crockford par
    /// groupes de 5 caractères. Le client vous l'envoie, vous le collez dans le générateur.
    /// </summary>
    public static class CodeDemande
    {
        public const byte Version = 1;
        public const int NombreComposants = 5;
        public const int TailleComposant = 5;
        public const int TailleEmpreinte = NombreComposants * TailleComposant;

        private const string Alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";

        public static string Construire(byte[] empreinte)
        {
            if (empreinte == null || empreinte.Length != TailleEmpreinte)
                throw new ArgumentException("Empreinte invalide.");

            var donnees = new byte[1 + TailleEmpreinte + 2];
            donnees[0] = Version;
            Buffer.BlockCopy(empreinte, 0, donnees, 1, TailleEmpreinte);
            byte[] controle = Controle(donnees, 1 + TailleEmpreinte);
            donnees[donnees.Length - 2] = controle[0];
            donnees[donnees.Length - 1] = controle[1];

            string brut = EncoderBase32(donnees);
            var groupes = new List<string>();
            for (int i = 0; i < brut.Length; i += 5)
                groupes.Add(brut.Substring(i, Math.Min(5, brut.Length - i)));
            return string.Join("-", groupes);
        }

        public static bool TryAnalyser(string code, out byte[] empreinte, out string erreur)
        {
            empreinte = null;
            erreur = null;
            if (string.IsNullOrWhiteSpace(code))
            {
                erreur = "Le code de demande est vide.";
                return false;
            }

            var sb = new StringBuilder();
            foreach (char brut in code.ToUpperInvariant())
            {
                char c = brut;
                if (c == '-' || char.IsWhiteSpace(c)) continue;
                if (c == 'O') c = '0';
                if (c == 'I' || c == 'L') c = '1';
                if (Alphabet.IndexOf(c) < 0)
                {
                    erreur = "Le code de demande contient un caractère invalide : « " + brut + " ».";
                    return false;
                }
                sb.Append(c);
            }

            byte[] donnees;
            if (!TryDecoderBase32(sb.ToString(), 1 + TailleEmpreinte + 2, out donnees))
            {
                erreur = "Le code de demande est incomplet ou trop long.";
                return false;
            }
            if (donnees[0] != Version)
            {
                erreur = "Version de code de demande non prise en charge.";
                return false;
            }
            byte[] controle = Controle(donnees, 1 + TailleEmpreinte);
            if (controle[0] != donnees[donnees.Length - 2] || controle[1] != donnees[donnees.Length - 1])
            {
                erreur = "Le code de demande est erroné (faute de frappe ?).";
                return false;
            }

            empreinte = new byte[TailleEmpreinte];
            Buffer.BlockCopy(donnees, 1, empreinte, 0, TailleEmpreinte);
            return true;
        }

        private static byte[] Controle(byte[] donnees, int longueur)
        {
            using (var sha = SHA256.Create())
            {
                byte[] prefixe = Encoding.ASCII.GetBytes("SIGMA-CODE-DEMANDE|");
                var tampon = new byte[prefixe.Length + longueur];
                Buffer.BlockCopy(prefixe, 0, tampon, 0, prefixe.Length);
                Buffer.BlockCopy(donnees, 0, tampon, prefixe.Length, longueur);
                return sha.ComputeHash(tampon);
            }
        }

        private static string EncoderBase32(byte[] donnees)
        {
            var sb = new StringBuilder();
            int tampon = 0, bits = 0;
            foreach (byte b in donnees)
            {
                tampon = (tampon << 8) | b;
                bits += 8;
                while (bits >= 5)
                {
                    sb.Append(Alphabet[(tampon >> (bits - 5)) & 31]);
                    bits -= 5;
                }
                tampon &= (1 << bits) - 1;
            }
            if (bits > 0)
                sb.Append(Alphabet[(tampon << (5 - bits)) & 31]);
            return sb.ToString();
        }

        private static bool TryDecoderBase32(string texte, int tailleAttendue, out byte[] resultat)
        {
            resultat = null;
            int caracteresAttendus = (tailleAttendue * 8 + 4) / 5;
            if (texte.Length != caracteresAttendus) return false;

            var octets = new List<byte>();
            int tampon = 0, bits = 0;
            foreach (char c in texte)
            {
                tampon = (tampon << 5) | Alphabet.IndexOf(c);
                bits += 5;
                if (bits >= 8)
                {
                    octets.Add((byte)((tampon >> (bits - 8)) & 0xFF));
                    bits -= 8;
                }
                tampon &= 0xFFFF;
            }
            // Les bits de bourrage restants doivent être nuls (forme canonique unique).
            if (bits > 0 && (tampon & ((1 << bits) - 1)) != 0) return false;
            if (octets.Count != tailleAttendue) return false;
            resultat = octets.ToArray();
            return true;
        }
    }

    /// <summary>
    /// Comparaison tolérante d'empreintes : un composant matériel peut changer (disque
    /// remplacé, BIOS mis à jour) sans invalider la licence, tant qu'une majorité des
    /// composants présents concorde.
    /// </summary>
    public static class ComparateurEmpreinte
    {
        public static bool ComposantPresent(byte[] empreinte, int index)
        {
            for (int j = 0; j < CodeDemande.TailleComposant; j++)
                if (empreinte[index * CodeDemande.TailleComposant + j] != 0) return true;
            return false;
        }

        public static int ComposantsPresents(byte[] empreinte)
        {
            if (empreinte == null || empreinte.Length != CodeDemande.TailleEmpreinte) return 0;
            int n = 0;
            for (int i = 0; i < CodeDemande.NombreComposants; i++)
                if (ComposantPresent(empreinte, i)) n++;
            return n;
        }

        public static bool Correspond(byte[] empreinteLicence, byte[] empreinteActuelle, out int concordants, out int requis)
        {
            concordants = 0;
            requis = 0;
            if (empreinteLicence == null || empreinteActuelle == null
                || empreinteLicence.Length != CodeDemande.TailleEmpreinte
                || empreinteActuelle.Length != CodeDemande.TailleEmpreinte)
                return false;

            int presents = ComposantsPresents(empreinteLicence);
            if (presents < 2) return false; // empreinte trop pauvre pour être fiable
            requis = Math.Min(3, presents);

            for (int i = 0; i < CodeDemande.NombreComposants; i++)
            {
                if (!ComposantPresent(empreinteLicence, i)) continue;
                bool egal = true;
                for (int j = 0; j < CodeDemande.TailleComposant; j++)
                {
                    int k = i * CodeDemande.TailleComposant + j;
                    if (empreinteLicence[k] != empreinteActuelle[k]) { egal = false; break; }
                }
                if (egal) concordants++;
            }
            return concordants >= requis;
        }
    }
}
