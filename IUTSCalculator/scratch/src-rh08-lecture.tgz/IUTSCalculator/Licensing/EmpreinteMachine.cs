using System;
using System.Linq;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

// ═══════════════════════════════════════════════════════════════════════════════
//  EMPREINTE MATÉRIELLE DU POSTE (application uniquement)
//
//  Produit une empreinte de 25 octets = 5 composants indépendants de 5 octets, un
//  par caractéristique stable du poste (identifiant Windows, carte mère, BIOS,
//  processeur, volume système). Chaque composant est un condensé SHA-256 tronqué,
//  salé avec un libellé propre : impossible de remonter à la valeur matérielle
//  d'origine, et deux composants ne peuvent pas se confondre.
//
//  La comparaison (voir ComparateurEmpreinte) est tolérante : il suffit qu'une
//  majorité des composants concorde. Un composant illisible est laissé à zéro et
//  simplement ignoré, de sorte qu'un poste où WMI est partiellement restreint
//  reste activable.
// ═══════════════════════════════════════════════════════════════════════════════

namespace IUTSCalculator.Licensing
{
    public static class EmpreinteMachine
    {
        private const string Sel = "SIGMA-PAIE-RH|EMPREINTE|v1";

        public static byte[] Calculer()
        {
            var composants = new[]
            {
                Composant("WINID", IdentifiantWindows()),
                Composant("CARTEMERE", NumeroSerie("Win32_BaseBoard", "SerialNumber")),
                Composant("BIOS", NumeroSerie("Win32_BIOS", "SerialNumber")),
                Composant("CPU", IdentifiantProcesseur()),
                Composant("VOLUME", NumeroVolumeSysteme())
            };

            var empreinte = new byte[CodeDemande.TailleEmpreinte];
            for (int i = 0; i < composants.Length; i++)
                Buffer.BlockCopy(composants[i], 0, empreinte, i * CodeDemande.TailleComposant, CodeDemande.TailleComposant);
            return empreinte;
        }

        public static string CodeDemandeActuel()
        {
            return CodeDemande.Construire(Calculer());
        }

        private static byte[] Composant(string libelle, string valeur)
        {
            // Une valeur vide, générique ou manifestement bidon laisse le composant à zéro :
            // il sera ignoré par le comparateur plutôt que de produire une fausse concordance.
            if (string.IsNullOrWhiteSpace(valeur))
                return new byte[CodeDemande.TailleComposant];

            string normalise = valeur.Trim().ToUpperInvariant();
            if (EstValeurInutile(normalise))
                return new byte[CodeDemande.TailleComposant];

            using (var sha = SHA256.Create())
            {
                byte[] condense = sha.ComputeHash(Encoding.UTF8.GetBytes(Sel + "|" + libelle + "|" + normalise));
                var resultat = new byte[CodeDemande.TailleComposant];
                Buffer.BlockCopy(condense, 0, resultat, 0, CodeDemande.TailleComposant);
                // Un composant présent ne doit pas être tout à zéro (réservé à « absent »).
                if (resultat.All(b => b == 0)) resultat[0] = 1;
                return resultat;
            }
        }

        private static bool EstValeurInutile(string v)
        {
            switch (v)
            {
                case "0":
                case "NONE":
                case "N/A":
                case "NA":
                case "DEFAULT STRING":
                case "TO BE FILLED BY O.E.M.":
                case "SYSTEM SERIAL NUMBER":
                case "NOT SPECIFIED":
                case "NOT APPLICABLE":
                case "INVALID":
                case "FFFFFFFFFFFFFFFF":
                case "00000000-0000-0000-0000-000000000000":
                    return true;
            }
            return v.Length < 2 || v.All(c => c == '0') || v.All(c => c == 'F');
        }

        private static string IdentifiantWindows()
        {
            // MachineGuid : stable, propre à l'installation Windows, lisible sans WMI.
            foreach (var vue in new[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                try
                {
                    using (var baseKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, vue))
                    using (var cle = baseKey.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography"))
                    {
                        var valeur = cle?.GetValue("MachineGuid") as string;
                        if (!string.IsNullOrWhiteSpace(valeur)) return valeur;
                    }
                }
                catch { /* composant ignoré */ }
            }
            return null;
        }

        private static string NumeroSerie(string classe, string propriete)
        {
            return LireWmi(classe, propriete);
        }

        private static string IdentifiantProcesseur()
        {
            string id = LireWmi("Win32_Processor", "ProcessorId");
            if (!string.IsNullOrWhiteSpace(id)) return id;
            // Repli : combinaison stable qui ne dépend pas de l'identifiant unique.
            string nom = LireWmi("Win32_Processor", "Name");
            string coeurs = LireWmi("Win32_Processor", "NumberOfCores");
            string combinaison = (nom + "|" + coeurs).Trim('|');
            return combinaison.Length > 1 ? combinaison : null;
        }

        private static string NumeroVolumeSysteme()
        {
            try
            {
                string racine = System.IO.Path.GetPathRoot(Environment.SystemDirectory);
                if (string.IsNullOrEmpty(racine)) return null;
                string lettre = racine.TrimEnd('\\', '/').TrimEnd(':');
                return LireWmi("Win32_LogicalDisk", "VolumeSerialNumber", "DeviceID='" + lettre + ":'");
            }
            catch
            {
                return null;
            }
        }

        private static string LireWmi(string classe, string propriete, string condition = null)
        {
            try
            {
                string requete = "SELECT " + propriete + " FROM " + classe;
                if (!string.IsNullOrEmpty(condition)) requete += " WHERE " + condition;

                using (var chercheur = new ManagementObjectSearcher(requete))
                using (var resultats = chercheur.Get())
                {
                    foreach (ManagementObject obj in resultats)
                    {
                        using (obj)
                        {
                            var valeur = obj[propriete];
                            if (valeur != null)
                            {
                                string texte = valeur.ToString();
                                if (!string.IsNullOrWhiteSpace(texte)) return texte;
                            }
                        }
                    }
                }
            }
            catch
            {
                // WMI indisponible ou restreint : composant laissé absent.
            }
            return null;
        }
    }
}
