namespace IUTSCalculator.Licensing
{
    // Fichier généré automatiquement par le générateur de licences.
    // Remplacez le fichier du même nom dans le projet de l'application, puis recompilez.
    public static class LicenceClesPubliques
    {
        public static readonly byte[] Licence = new byte[] { 124, 231, 85, 144, 94, 166, 247, 147, 22, 133, 52, 57, 95, 150, 153, 23, 63, 133, 247, 30, 42, 191, 54, 186, 137, 92, 128, 71, 22, 222, 112, 133 };
        public static readonly byte[] Serveur = new byte[] { 69, 234, 250, 149, 35, 54, 60, 143, 73, 79, 243, 2, 56, 251, 26, 194, 195, 71, 140, 101, 203, 1, 49, 126, 107, 96, 204, 233, 139, 50, 159, 17 };
    }
}
