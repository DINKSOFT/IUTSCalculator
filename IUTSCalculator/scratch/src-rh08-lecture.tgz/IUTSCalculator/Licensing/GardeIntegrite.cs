using System;
using System.Threading;

// ═══════════════════════════════════════════════════════════════════════════════
//  GARDE D'INTÉGRITÉ (application uniquement)
//
//  Défense « en profondeur » contre le retrait du contrôle de licence par modification
//  du binaire. Plutôt qu'un unique test « si licence invalide → bloquer » (qu'un seul
//  patch neutralise), plusieurs sondes légères, appelées depuis des endroits variés et
//  à des moments variés, revérifient le verdict de façon INDÉPENDANTE.
//
//  Réaction volontairement DIFFÉRÉE et DISCRÈTE : une sonde qui constate une anomalie
//  n'affiche pas aussitôt un message « licence requise » (ce qui pointerait l'endroit à
//  neutraliser). Elle incrémente un compteur de soupçon ; au-delà d'un seuil, et après
//  un délai aléatoire, l'application se dégrade (fermeture propre). Le lien de cause à
//  effet est ainsi distendu, ce qui complique l'analyse — y compris assistée par IA.
//
//  Important : ce dispositif ne protège PAS les données ni ne « casse » quoi que ce soit
//  d'irréversible. Il se contente de fermer l'application. La garantie dure reste la
//  signature : personne ne peut fabriquer de licence valide. Ceci ne fait que renchérir
//  le contournement par recompilation/patch.
// ═══════════════════════════════════════════════════════════════════════════════

namespace IUTSCalculator.Licensing
{
    public static class GardeIntegrite
    {
        private static int _soupcon;
        private static int _degradationLancee;
        private const int Seuil = 3;

        /// <summary>
        /// Action de fermeture injectée par l'application (ex. Application.Current.Shutdown).
        /// Laissée nulle → Environment.FailFast en dernier recours.
        /// </summary>
        public static Action Fermeture { get; set; }

        /// <summary>
        /// Sonde à semer en divers points « chauds » (ouverture d'un écran sensible,
        /// génération d'un document, enregistrement). Ne bloque pas l'appelant.
        /// </summary>
        public static void Sonder()
        {
            try
            {
                bool ok = LicenceService.Instance.EstActiveStricte();
                if (ok)
                {
                    // Un succès franc relâche progressivement la pression (tolère un faux positif isolé).
                    if (Volatile.Read(ref _soupcon) > 0)
                        Interlocked.Decrement(ref _soupcon);
                    return;
                }
            }
            catch
            {
                // Une exception dans la sonde compte comme un soupçon (sabotage possible).
            }

            if (Interlocked.Increment(ref _soupcon) >= Seuil)
                DeclencherDegradation();
        }

        /// <summary>
        /// Barrière franche pour les actions qui ne doivent PAS s'exécuter sans droit
        /// (création de salarié, édition d'un document officiel…). Renvoie false si l'action
        /// doit être refusée. À utiliser EN PLUS du verrouillage de navigation, jamais seule.
        /// </summary>
        public static bool AutoriserAction(string nomTypeViewModel)
        {
            try
            {
                return LicenceService.Instance.EstModuleAutorise(nomTypeViewModel);
            }
            catch
            {
                return false;
            }
        }

        private static void DeclencherDegradation()
        {
            if (Interlocked.Exchange(ref _degradationLancee, 1) == 1)
                return;

            // Délai aléatoire (10–40 s) sur un thread de fond : la fermeture ne coïncide pas
            // avec la sonde qui l'a motivée, ce qui brouille la recherche du point de contrôle.
            var rng = new Random();
            int delai = 10000 + rng.Next(30000);
            var minuterie = new Timer(_ =>
            {
                try
                {
                    // Dernière vérification : si la situation est redevenue saine entre-temps, on renonce.
                    if (LicenceService.Instance.EstActiveStricte())
                    {
                        Interlocked.Exchange(ref _degradationLancee, 0);
                        Interlocked.Exchange(ref _soupcon, 0);
                        return;
                    }
                }
                catch { /* on ferme quand même */ }

                Fermer();
            }, null, delai, Timeout.Infinite);

            // Empêche le ramasse-miettes de collecter la minuterie avant son déclenchement.
            GC.KeepAlive(minuterie);
        }

        private static void Fermer()
        {
            var action = Fermeture;
            if (action != null)
            {
                try { action(); return; }
                catch { /* repli ci-dessous */ }
            }
            Environment.FailFast(null); // sans message : pas d'indice exploitable
        }
    }
}
