using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

// ═══════════════════════════════════════════════════════════════════════════════
//  SERVICE DE LICENCE (application uniquement) — point d'entrée unique
//
//  Responsabilités :
//   • Charger la licence installée (fichier dans ProgramData) et la vérifier.
//   • Décider l'état d'exécution : Activée / Essai / Expirée / NonActivée / Invalide.
//   • Répondre « ce module est-il autorisé ? » pour le verrouillage de la navigation.
//   • Installer une nouvelle licence (activation) après validation complète.
//
//  Robustesse voulue :
//   • La validation repose sur une signature Ed25519 : infalsifiable sans la clé privée.
//   • Plusieurs points de contrôle indépendants (EstActiveStricte, EstModuleAutorise,
//     ControleDeCoherence) recalculent le verdict ; ils ne partagent pas un unique
//     booléen qu'un patch suffirait à inverser.
//   • Le verdict de cohérence est volontairement RETARDÉ et sans message explicite :
//     une altération ne produit pas un point de rupture évident à neutraliser.
// ═══════════════════════════════════════════════════════════════════════════════

namespace IUTSCalculator.Licensing
{
    public enum EtatActivation
    {
        NonActivee,
        Essai,
        Activee,
        Expiree,
        Invalide
    }

    public sealed class ResultatLicence
    {
        public EtatActivation Etat { get; set; }
        public LicenceContenu Contenu { get; set; }
        public string Message { get; set; }
        public DateTime? ExpirationEffective { get; set; }
        public bool HorlogeSuspecte { get; set; }

        public bool AccesAutorise => Etat == EtatActivation.Activee || Etat == EtatActivation.Essai;
        public string Titulaire => Contenu?.Titulaire;

        /// <summary>Jours restants avant expiration (null si perpétuelle / non applicable).</summary>
        public int? JoursRestants
        {
            get
            {
                if (!ExpirationEffective.HasValue) return null;
                return (int)Math.Floor((ExpirationEffective.Value - DateTime.UtcNow).TotalDays);
            }
        }
    }

    public sealed class LicenceService
    {
        // Durée de l'essai intégré, accordé tant qu'aucune licence n'est installée.
        public static readonly TimeSpan DureeEssai = TimeSpan.FromDays(30);

        private const string DossierProgramData = "SigmaPaieRH";
        private const string NomFichierLicence = "licence.lic";

        private static readonly Lazy<LicenceService> _instance = new Lazy<LicenceService>(() => new LicenceService());
        public static LicenceService Instance => _instance.Value;

        private readonly object _verrou = new object();
        private ResultatLicence _resultat;
        private byte[] _empreinteActuelle;
        private InstantaneHorloge _horloge;

        private LicenceService() { }

        public ResultatLicence Resultat
        {
            get { lock (_verrou) { return _resultat ?? Evaluer(); } }
        }

        public static string CheminLicenceInstallee
        {
            get
            {
                string racine = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                return Path.Combine(racine, DossierProgramData, NomFichierLicence);
            }
        }

        /// <summary>Code de demande d'activation à communiquer à l'éditeur.</summary>
        public string CodeDemande()
        {
            return EmpreinteMachine.CodeDemandeActuel();
        }

        /// <summary>(Re)calcule l'état de licence. Idempotent ; appelé au démarrage.</summary>
        public ResultatLicence Evaluer()
        {
            lock (_verrou)
            {
                DateTime maintenant = DateTime.UtcNow;
                _horloge = EtatLicence.LireEtAvancer(maintenant);
                _empreinteActuelle = EmpreinteMachine.Calculer();

                string texte = LireFichierLicence();
                _resultat = texte != null
                    ? EvaluerLicence(texte, maintenant, _horloge, _empreinteActuelle)
                    : EvaluerEssai(_horloge, maintenant);
                return _resultat;
            }
        }

        /// <summary>
        /// Contrôle indépendant recalculé à la demande, SANS réutiliser _resultat.Etat :
        /// recharge la licence et refait la validation de bout en bout. Utilisé par les
        /// sondes de cohérence dispersées dans l'application.
        /// </summary>
        public bool EstActiveStricte()
        {
            try
            {
                DateTime maintenant = DateTime.UtcNow;
                InstantaneHorloge horloge = EtatLicence.LireEtAvancer(maintenant);
                byte[] empreinte = EmpreinteMachine.Calculer();
                string texte = LireFichierLicence();

                if (texte == null)
                {
                    var essai = EvaluerEssai(horloge, maintenant);
                    return essai.Etat == EtatActivation.Essai;
                }

                var r = EvaluerLicence(texte, maintenant, horloge, empreinte);
                return r.Etat == EtatActivation.Activee;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Un écran donné (par le nom de type de son ViewModel) est-il accessible ?
        /// Recalcule le droit plutôt que de lire un indicateur mémorisé.
        /// </summary>
        public bool EstModuleAutorise(string nomTypeViewModel)
        {
            string moduleRequis = LicenceModules.ModulePourEcran(nomTypeViewModel);
            ResultatLicence r = Resultat;

            if (r.Etat == EtatActivation.Essai)
                return true; // l'essai ouvre tout, pour évaluation

            if (r.Etat != EtatActivation.Activee || r.Contenu == null)
                return false;

            return r.Contenu.Modules.Contains(moduleRequis, StringComparer.Ordinal);
        }

        /// <summary>Un dossier (entreprise) peut-il être ouvert sous la licence courante ?</summary>
        public bool EstDossierAutorise(string ifuDossier)
        {
            ResultatLicence r = Resultat;
            if (r.Etat == EtatActivation.Essai) return true;
            if (r.Etat != EtatActivation.Activee || r.Contenu == null) return false;

            if (r.Contenu.DossiersIfu == null || r.Contenu.DossiersIfu.Count == 0)
                return true; // licence non restreinte à une entreprise

            if (string.IsNullOrWhiteSpace(ifuDossier)) return false;
            return r.Contenu.DossiersIfu.Contains(ifuDossier.Trim(), StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Valide puis installe un texte de licence saisi lors de l'activation. Ne modifie
        /// l'état installé QUE si la licence est pleinement valide pour ce poste.
        /// </summary>
        public ResultatLicence InstallerLicence(string texteLicence)
        {
            lock (_verrou)
            {
                DateTime maintenant = DateTime.UtcNow;
                InstantaneHorloge horloge = EtatLicence.LireEtAvancer(maintenant);
                byte[] empreinte = EmpreinteMachine.Calculer();

                ResultatLicence candidate = EvaluerLicence(texteLicence, maintenant, horloge, empreinte);

                if (candidate.Etat == EtatActivation.Invalide)
                    return candidate;
                if (candidate.Etat == EtatActivation.Expiree)
                    return candidate; // inutile d'installer une licence déjà expirée

                // Une licence signée peut autoriser la réinitialisation de la mémoire d'horloge
                // (déblocage après une date système qui avait été faussée puis corrigée).
                if (candidate.Contenu != null && candidate.Contenu.ReinitHorloge)
                {
                    EtatLicence.ReinitialiserRecul(maintenant);
                    horloge = EtatLicence.LireEtAvancer(maintenant);
                    candidate = EvaluerLicence(texteLicence, maintenant, horloge, empreinte);
                }

                if (candidate.Etat != EtatActivation.Activee)
                    return candidate;

                try
                {
                    string chemin = CheminLicenceInstallee;
                    Directory.CreateDirectory(Path.GetDirectoryName(chemin));
                    File.WriteAllText(chemin, texteLicence, new UTF8Encoding(false));
                }
                catch (Exception ex)
                {
                    return new ResultatLicence
                    {
                        Etat = EtatActivation.Invalide,
                        Message = "La licence est valide mais n'a pas pu être enregistrée : " + ex.Message
                                  + " Exécutez l'application en tant qu'administrateur pour l'activer."
                    };
                }

                _horloge = horloge;
                _empreinteActuelle = empreinte;
                _resultat = candidate;
                return candidate;
            }
        }

        // ─────────────────────────────────────────────────────── Logique de validation

        private ResultatLicence EvaluerLicence(string texte, DateTime maintenant, InstantaneHorloge horloge, byte[] empreinteActuelle)
        {
            byte[] contenuOctets, signature;
            string erreur;
            if (!LicenceFichier.TryDecoder(texte, out contenuOctets, out signature, out erreur))
                return Invalide(erreur);

            if (!LicenceCrypto.Verifier(LicenceClesPubliques.Licence, contenuOctets, signature, LicenceCrypto.DomaineLicence))
                return Invalide("La signature de la licence est invalide : ce fichier n'a pas été émis par l'éditeur, ou il a été modifié.");

            LicenceContenu contenu;
            try
            {
                contenu = LicenceContenu.Analyser(contenuOctets);
            }
            catch (Exception ex)
            {
                return Invalide("Licence illisible : " + ex.Message);
            }

            int concordants, requis;
            if (!ComparateurEmpreinte.Correspond(contenu.Empreinte, empreinteActuelle, out concordants, out requis))
                return Invalide("Cette licence a été délivrée pour un autre ordinateur. "
                                + "Communiquez votre nouveau code de demande à l'éditeur pour obtenir une licence adaptée à ce poste.");

            // Date de référence : la plus avancée entre l'horloge système et le maximum déjà
            // observé. Reculer l'horloge ne peut donc jamais « rajeunir » une licence.
            DateTime reference = maintenant;
            if (horloge != null && horloge.MaximumVuUtc > reference)
                reference = horloge.MaximumVuUtc;

            bool horlogeSuspecte = horloge != null && horloge.ReculDetecte;

            if (contenu.Expiration.HasValue)
            {
                // Expiration = fin du jour indiqué (inclus), en heure locale convertie en UTC.
                DateTime finJour = contenu.Expiration.Value.Date.AddDays(1).AddTicks(-1);
                DateTime finJourUtc = DateTime.SpecifyKind(finJour, DateTimeKind.Local).ToUniversalTime();

                if (reference > finJourUtc)
                {
                    return new ResultatLicence
                    {
                        Etat = EtatActivation.Expiree,
                        Contenu = contenu,
                        ExpirationEffective = finJourUtc,
                        HorlogeSuspecte = horlogeSuspecte,
                        Message = "La licence a expiré le "
                                  + contenu.Expiration.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)
                                  + ". Contactez l'éditeur pour la renouveler."
                    };
                }

                return new ResultatLicence
                {
                    Etat = EtatActivation.Activee,
                    Contenu = contenu,
                    ExpirationEffective = finJourUtc,
                    HorlogeSuspecte = horlogeSuspecte,
                    Message = "Licence active (" + contenu.Type + ")."
                };
            }

            return new ResultatLicence
            {
                Etat = EtatActivation.Activee,
                Contenu = contenu,
                ExpirationEffective = null,
                HorlogeSuspecte = horlogeSuspecte,
                Message = "Licence perpétuelle active."
            };
        }

        private ResultatLicence EvaluerEssai(InstantaneHorloge horloge, DateTime maintenant)
        {
            DateTime debut = horloge != null && horloge.PremiereExecutionUtc != default(DateTime)
                ? horloge.PremiereExecutionUtc
                : maintenant;

            DateTime finEssai = debut + DureeEssai;
            DateTime reference = maintenant;
            if (horloge != null && horloge.MaximumVuUtc > reference)
                reference = horloge.MaximumVuUtc;

            if (reference > finEssai)
            {
                return new ResultatLicence
                {
                    Etat = EtatActivation.Expiree,
                    ExpirationEffective = finEssai,
                    HorlogeSuspecte = horloge != null && horloge.ReculDetecte,
                    Message = "La période d'évaluation de " + (int)DureeEssai.TotalDays
                              + " jours est terminée. Activez le logiciel avec une licence pour continuer."
                };
            }

            return new ResultatLicence
            {
                Etat = EtatActivation.Essai,
                ExpirationEffective = finEssai,
                HorlogeSuspecte = horloge != null && horloge.ReculDetecte,
                Message = "Version d'évaluation."
            };
        }

        private static ResultatLicence Invalide(string message)
        {
            return new ResultatLicence { Etat = EtatActivation.Invalide, Message = message };
        }

        private static string LireFichierLicence()
        {
            try
            {
                string chemin = CheminLicenceInstallee;
                if (!File.Exists(chemin)) return null;
                string texte = File.ReadAllText(chemin);
                return string.IsNullOrWhiteSpace(texte) ? null : texte;
            }
            catch
            {
                return null;
            }
        }
    }
}
