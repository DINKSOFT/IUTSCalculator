using System;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

// ═══════════════════════════════════════════════════════════════════════════════
//  ÉTAT LOCAL DE LA LICENCE (application uniquement)
//
//  Deux rôles :
//   1. Mémoriser la date la plus récente jamais observée (horloge) afin de détecter
//      un recul volontaire de l'horloge système destiné à contourner une expiration.
//   2. Mémoriser, par simple marqueur, le début de la période d'essai.
//
//  L'état est écrit À DEUX ENDROITS redondants — un fichier chiffré DPAPI (portée
//  machine) dans ProgramData, et une valeur de registre HKLM — puis relu en prenant
//  la valeur la plus avancée des deux. Effacer l'un ne suffit donc pas, et comme la
//  date retenue ne fait que croître, restaurer une ancienne copie n'aide pas non plus.
//
//  Cet état n'est PAS une barrière cryptographique (un administrateur peut tout
//  effacer) : son rôle est de rendre la triche à l'horloge peu pratique et visible,
//  la garantie dure venant de la signature de la licence elle-même.
// ═══════════════════════════════════════════════════════════════════════════════

namespace IUTSCalculator.Licensing
{
    public sealed class InstantaneHorloge
    {
        /// <summary>Date/heure la plus avancée jamais constatée sur ce poste (UTC).</summary>
        public DateTime MaximumVuUtc { get; set; }

        /// <summary>Première exécution connue (UTC) — sert de début de période d'essai.</summary>
        public DateTime PremiereExecutionUtc { get; set; }

        /// <summary>Vrai si un recul d'horloge supérieur à la tolérance a déjà été constaté.</summary>
        public bool ReculDetecte { get; set; }
    }

    public static class EtatLicence
    {
        // Tolérance : on n'alerte que pour un recul franc (fuseau, correction NTP mineure tolérés).
        private static readonly TimeSpan ToleranceRecul = TimeSpan.FromHours(26);

        private const string DossierProgramData = "SigmaPaieRH";
        private const string NomFichierEtat = "etat.dat";
        private const string CleRegistre = @"SOFTWARE\SigmaPaieRH";
        private const string ValeurRegistre = "Etat";
        private const string Entete = "SIGMA-ETAT-1";

        private static readonly object Verrou = new object();

        private static string CheminFichier
        {
            get
            {
                string racine = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                return Path.Combine(racine, DossierProgramData, NomFichierEtat);
            }
        }

        /// <summary>
        /// Lit l'état, le compare à « maintenant », met à jour le maximum observé et
        /// renvoie l'instantané consolidé. À appeler une fois au démarrage.
        /// </summary>
        public static InstantaneHorloge LireEtAvancer(DateTime maintenantUtc)
        {
            lock (Verrou)
            {
                InstantaneHorloge etat = Fusionner(LireFichier(), LireRegistre()) ?? new InstantaneHorloge
                {
                    MaximumVuUtc = maintenantUtc,
                    PremiereExecutionUtc = maintenantUtc,
                    ReculDetecte = false
                };

                if (etat.PremiereExecutionUtc == default(DateTime) || etat.PremiereExecutionUtc > maintenantUtc)
                {
                    // Première exécution, ou horloge réglée AVANT la première exécution connue :
                    // dans les deux cas on ancre le début d'essai au plus tôt des deux.
                    if (etat.PremiereExecutionUtc == default(DateTime))
                        etat.PremiereExecutionUtc = maintenantUtc;
                    else if (maintenantUtc < etat.PremiereExecutionUtc)
                        etat.PremiereExecutionUtc = maintenantUtc;
                }

                if (maintenantUtc + ToleranceRecul < etat.MaximumVuUtc)
                    etat.ReculDetecte = true;

                if (maintenantUtc > etat.MaximumVuUtc)
                    etat.MaximumVuUtc = maintenantUtc;

                Ecrire(etat);
                return etat;
            }
        }

        /// <summary>Efface le marqueur de recul (appelé lorsqu'une licence signée demande une réinitialisation).</summary>
        public static void ReinitialiserRecul(DateTime maintenantUtc)
        {
            lock (Verrou)
            {
                InstantaneHorloge etat = Fusionner(LireFichier(), LireRegistre()) ?? new InstantaneHorloge();
                etat.ReculDetecte = false;
                etat.MaximumVuUtc = maintenantUtc;
                if (etat.PremiereExecutionUtc == default(DateTime)) etat.PremiereExecutionUtc = maintenantUtc;
                Ecrire(etat);
            }
        }

        private static InstantaneHorloge Fusionner(InstantaneHorloge a, InstantaneHorloge b)
        {
            if (a == null) return b;
            if (b == null) return a;
            return new InstantaneHorloge
            {
                MaximumVuUtc = a.MaximumVuUtc > b.MaximumVuUtc ? a.MaximumVuUtc : b.MaximumVuUtc,
                PremiereExecutionUtc = ChoisirPremiere(a.PremiereExecutionUtc, b.PremiereExecutionUtc),
                ReculDetecte = a.ReculDetecte || b.ReculDetecte
            };
        }

        private static DateTime ChoisirPremiere(DateTime a, DateTime b)
        {
            if (a == default(DateTime)) return b;
            if (b == default(DateTime)) return a;
            return a < b ? a : b;
        }

        private static void Ecrire(InstantaneHorloge etat)
        {
            string charge = Serialiser(etat);
            EcrireFichier(charge);
            EcrireRegistre(charge);
        }

        private static string Serialiser(InstantaneHorloge etat)
        {
            return string.Join("|",
                Entete,
                etat.MaximumVuUtc.ToUniversalTime().Ticks.ToString(CultureInfo.InvariantCulture),
                etat.PremiereExecutionUtc.ToUniversalTime().Ticks.ToString(CultureInfo.InvariantCulture),
                etat.ReculDetecte ? "1" : "0");
        }

        private static InstantaneHorloge Deserialiser(string texte)
        {
            if (string.IsNullOrWhiteSpace(texte)) return null;
            var parts = texte.Split('|');
            if (parts.Length != 4 || parts[0] != Entete) return null;
            long maxTicks, premTicks;
            if (!long.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out maxTicks)) return null;
            if (!long.TryParse(parts[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out premTicks)) return null;
            if (maxTicks < 0 || premTicks < 0 || maxTicks > DateTime.MaxValue.Ticks || premTicks > DateTime.MaxValue.Ticks)
                return null;
            return new InstantaneHorloge
            {
                MaximumVuUtc = new DateTime(maxTicks, DateTimeKind.Utc),
                PremiereExecutionUtc = new DateTime(premTicks, DateTimeKind.Utc),
                ReculDetecte = parts[3] == "1"
            };
        }

        // ─────────────────────────────────────────────────────── Support fichier (DPAPI)

        private static InstantaneHorloge LireFichier()
        {
            try
            {
                string chemin = CheminFichier;
                if (!File.Exists(chemin)) return null;
                byte[] chiffre = File.ReadAllBytes(chemin);
                byte[] clair = ProtectedData.Unprotect(chiffre, EntropieDpapi, DataProtectionScope.LocalMachine);
                return Deserialiser(Encoding.UTF8.GetString(clair));
            }
            catch
            {
                return null;
            }
        }

        private static void EcrireFichier(string charge)
        {
            try
            {
                string chemin = CheminFichier;
                Directory.CreateDirectory(Path.GetDirectoryName(chemin));
                byte[] chiffre = ProtectedData.Protect(Encoding.UTF8.GetBytes(charge), EntropieDpapi, DataProtectionScope.LocalMachine);
                File.WriteAllBytes(chemin, chiffre);
            }
            catch
            {
                // Écriture best-effort : l'autre support (registre) prend le relais.
            }
        }

        private static readonly byte[] EntropieDpapi = Encoding.ASCII.GetBytes("SIGMA-PAIE-RH|ETAT|v1");

        // ─────────────────────────────────────────────────────── Support registre (HKLM)

        private static InstantaneHorloge LireRegistre()
        {
            foreach (var vue in new[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                try
                {
                    using (var baseKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, vue))
                    using (var cle = baseKey.OpenSubKey(CleRegistre))
                    {
                        var valeur = cle?.GetValue(ValeurRegistre) as string;
                        var etat = Deserialiser(Brouiller(valeur));
                        if (etat != null) return etat;
                    }
                }
                catch { /* support ignoré */ }
            }
            return null;
        }

        private static void EcrireRegistre(string charge)
        {
            foreach (var vue in new[] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                try
                {
                    using (var baseKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, vue))
                    using (var cle = baseKey.CreateSubKey(CleRegistre))
                    {
                        cle?.SetValue(ValeurRegistre, Brouiller(charge), RegistryValueKind.String);
                    }
                    return; // une vue suffit
                }
                catch { /* tentative suivante */ }
            }
        }

        // Brouillage symétrique léger : décourage l'édition manuelle de la valeur de registre
        // (ce n'est pas un secret, juste une gêne ; la sécurité réelle vient de la signature).
        private static string Brouiller(string texte)
        {
            if (string.IsNullOrEmpty(texte)) return texte;
            try
            {
                byte[] octets = Convert.FromBase64String(texte);
                return new string(Encoding.UTF8.GetChars(Xor(octets)));
            }
            catch (FormatException)
            {
                return Convert.ToBase64String(Xor(Encoding.UTF8.GetBytes(texte)));
            }
        }

        private static byte[] Xor(byte[] donnees)
        {
            byte[] cle = Encoding.ASCII.GetBytes("SigmaEtat");
            var sortie = new byte[donnees.Length];
            for (int i = 0; i < donnees.Length; i++)
                sortie[i] = (byte)(donnees[i] ^ cle[i % cle.Length]);
            return sortie;
        }
    }
}
